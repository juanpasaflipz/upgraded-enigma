'use client'

import { useEffect, useState } from 'react'

export default function Page(){
  const [spec, setSpec] = useState<any>(null)
  useEffect(()=>{ fetch('/spec.json').then(r=>r.json()).then(setSpec) },[])
  if(!spec) return <div className='p-8'>Loading…</div>
  return (
    <main className='max-w-3xl mx-auto p-8 space-y-6'>
      <h1 className='text-4xl font-bold'>{spec.title}</h1>
      <p className='text-zinc-300'>{spec.description}</p>
      <a href={spec.cta?.href || '#'} className='inline-block px-4 py-2 bg-emerald-500 text-black rounded-md'>
        {spec.cta?.label || 'Get Started'}
      </a>
      <section>
        <h2 className='text-2xl font-semibold mb-2'>Features</h2>
        <ul className='list-disc pl-6 space-y-1'>
          {(spec.features||[]).map((f:string,i:number)=>(<li key={i}>{f}</li>))}
        </ul>
      </section>
    </main>
  )
}
