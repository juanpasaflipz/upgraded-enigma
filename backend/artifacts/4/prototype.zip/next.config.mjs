export default { reactStrictMode: true }
